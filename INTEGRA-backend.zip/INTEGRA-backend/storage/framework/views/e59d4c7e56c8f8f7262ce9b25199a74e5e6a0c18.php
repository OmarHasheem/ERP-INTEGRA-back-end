<style>
    table {
       border-collapse: collapse;
       width: 100%;
     }

     th, td {
       border: 1px solid #ccc;
       padding: 8px;
       text-align: left;

     }

     th {
       background-color: #f2f2f2;
       font-weight: bold;
     }
     </style>

<!DOCTYPE html>
<html>
<head>

</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($date); ?></p>

    <table class="table table-bordered">
    <tr><th>Import</th></tr>
        <tr>
            <th>Name</th>
            <th>Date</th>
            <th>Total Amount</th>
            <th>Employee</th>
            <th>Supplier</th>
        </tr>
        <tr>
            <td><?php echo e($import->import_name); ?></td>
            <td><?php echo e($import->date); ?></td>
            <td><?php echo e($import->total_amount); ?></td>
            <td><?php echo e($import->employee_name); ?></td>
            <td><?php echo e($import->supplier_name); ?></td>
        </tr>
    </table>
    <br />

    <table class="table table-bordered">
    <tr><th>Products</th></tr>
        <tr>
            <th>Name</th>
            <th>Details</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total Amount</th>

        </tr>
        <?php $__currentLoopData = $import_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($products->product_name); ?></td>
            <?php $detailsObject = json_decode($products->details); ?>
            <td>
            <?php $__currentLoopData = $detailsObject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($key); ?>: <?php echo e($value); ?><br />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
            <td><?php echo e($products->price); ?></td>
            <td><?php echo e($products->quantity); ?></td>
            <td><?php echo e($products->total_amount); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</body>
</html>
<?php /**PATH C:\Users\user\OneDrive\Desktop\Junior\INTEGRA\INTEGRA-backend\junior-back-end\INTEGRA-backend\resources\views/ImportPDF.blade.php ENDPATH**/ ?>