<style>
    table {
       border-collapse: collapse;
       width: 100%;
     }

     th, td {
       border: 1px solid #ccc;
       padding: 8px;
       text-align: left;

     }

     th {
       background-color: #f2f2f2;
       font-weight: bold;
     }
     </style>

<!DOCTYPE html>
<html>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($date); ?></p>

    <table class="table table-bordered">
        <tr><th>Campaign</th></tr>
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Budget</th>
            <th>Status</th>
            <th>Expected Revenue</th>
            <th>Actual Revenue</th>

        </tr>

        <tr>
            <td><?php echo e($campaign->name); ?></td>
            <td><?php echo e($campaign->description); ?></td>
            <td><?php echo e($campaign->start_date); ?></td>
            <td><?php echo e($campaign->end_date); ?></td>
            <td><?php echo e($campaign->budget); ?></td>
            <td><?php echo e($campaign->status); ?></td>
            <td><?php echo e($campaign->expected_revenue); ?></td>
            <td><?php echo e($campaign->actual_revenue); ?></td>
        </tr>
        <br />

    </table>
    <?php if(isset($SM)): ?>

    <table class="table table-bordered">
    <tr><th>Social Media</th></tr>
        <tr>
            <th>Blogger</th>
            <th>Type</th>
            <th>Way</th>
            <th>Cost</th>
        </tr>
        <?php $__currentLoopData = $SM; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialmedia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($socialmedia->blogger); ?></td>
            <td><?php echo e($socialmedia->type); ?></td>
            <td><?php echo e($socialmedia->way); ?></td>
            <td><?php echo e($socialmedia->cost); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php endif; ?>
    <br />

    <?php if(isset($TV)): ?>

    <table class="table table-bordered">
    <tr><th>TV</th></tr>
        <tr>
            <th>Channel</th>
            <th>Time</th>
            <th>Cost</th>
            <th>Advertising Period</th>
        </tr>
        <?php $__currentLoopData = $TV; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tvs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($tvs->channel); ?></td>
            <td><?php echo e($tvs->time); ?></td>
            <td><?php echo e($tvs->cost); ?></td>
            <td><?php echo e($tvs->advertising_period); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php endif; ?>
    <br />

    <?php if(isset($EV)): ?>

    <table class="table table-bordered">
    <tr><th>Event</th></tr>
        <tr>
            <th>Place</th>
            <th>Description</th>
            <th>Type</th>
            <th>Event</th>
            <th>Cost</th>
        </tr>
        <?php $__currentLoopData = $EV; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($event->place); ?></td>
            <td><?php echo e($event->description); ?></td>
            <td><?php echo e($event->type); ?></td>
            <td><?php echo e($event->event); ?></td>
            <td><?php echo e($event->cost); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php endif; ?>

</body>
</html>
<?php /**PATH C:\Users\user\OneDrive\Desktop\Junior\INTEGRA\INTEGRA-backend\junior-back-end\INTEGRA-backend\resources\views/MarketingPDF.blade.php ENDPATH**/ ?>